class StudentSerializer < ActiveModel::Serializer
  attributes :id
end
