# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)
Artist.destroy_all
Album.destroy_all
Song.destroy_all

kanye = Artist.create(name:"Kanye West")
britney = Artist.create(name:"Britney Spears")
mj = Artist.create(name:"Michael Jackson")

kanye_album_one = kanye.albums.create(title:"808s and Heartbreak")
kanye_album_two = kanye.albums.create(title:"Graduation")
britney_album_one = britney.albums.create(title:"Britney Jean")
britney_album_two = britney.albums.create(title:"Circus")
mj_album_one = mj.albums.create(title:"Thriller")
mj_album_two = mj.albums.create(title:"Bad")

kanye_album_one.songs.create(title:"Say You Will")
kanye_album_one.songs.create(title:"Heartless")
kanye_album_two.songs.create(title:"Good Morning")
kanye_album_two.songs.create(title:"Champion")

britney_album_one.songs.create(title:"Alien")
britney_album_one.songs.create(title:"Perfume")
britney_album_two.songs.create(title:"Circus")
britney_album_two.songs.create(title:"Kill the Lights")

mj_album_one.songs.create(title:"Beat It")
mj_album_one.songs.create(title:"Billie Jean")
mj_album_two.songs.create(title:"The Way You Make Me Feel")
mj_album_two.songs.create(title:"Man in the Mirror")
