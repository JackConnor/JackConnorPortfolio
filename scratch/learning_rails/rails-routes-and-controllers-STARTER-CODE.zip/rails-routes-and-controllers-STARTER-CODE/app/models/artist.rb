class Artist < ActiveRecord::Base
  has_many :albums #Artist.first.albums
  has_many :songs, through: :albums #Artist.first.songs

  #Create an album that prefills the album_id field
  #Artist.first.albums.create(title:"Example")

  #Find artist's songs
  #Artist.first.songs
end
