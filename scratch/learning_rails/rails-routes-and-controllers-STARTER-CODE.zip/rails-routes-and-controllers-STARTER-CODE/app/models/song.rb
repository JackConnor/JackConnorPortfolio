class Song < ActiveRecord::Base
  belongs_to :album #Song.first.album
  has_one :artist, through: :album #Song.first.artist

  #Find the Album
  #Song.first.album

  #Find the Artist
  #Song.first.artist
end
