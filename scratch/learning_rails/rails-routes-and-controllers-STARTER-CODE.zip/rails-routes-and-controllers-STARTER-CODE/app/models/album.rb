class Album < ActiveRecord::Base
  belongs_to :artist #Album.first.artist
  has_many :songs #Album.first.songs

  #Create a song that prefills the song_id field
  #Album.first.songs.create(title:"Example")

  #Find the artist
  #Album.first.artist

  #Find the songs
  #Album.first.songs
end
